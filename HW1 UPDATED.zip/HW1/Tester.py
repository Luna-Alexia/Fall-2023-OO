from Bank_Account import Accounts

Test = Accounts()

#TestD = Accounts()

#print(Test.User_First_Name, Test.Last_Name, Test.Deposit)
Test.Deposit()
Test.Withdraw()
Test.Fee_Calculation()
Test.Interest()
print("_________________________")
print(Test.__str__())
