class Accounts:
    #User Info
    def __init__(self):
        self.User_First_Name = "Ant"
        self.Last_Name = "Galvich"
        self.Initial_Deposit = 500
        self.Fee_calc = 0 #intializes Fee to check under 1k
        self.balance_savepoint = 0 #intializes the flag for later use
        self.Current_balance = self.Initial_Deposit #ilnitalzies for later use, within fees
        print(f"User: {self.User_First_Name} {self.Last_Name}\nInitial Deposit: ${self.Initial_Deposit}")

    #Deposit
    def Deposit(self):
        self.Deposit_Amount = int(input(f"Deposit Amount: $")) #depoist input statement and adds to intial dep
        self.Final_Deposit = self.Initial_Deposit + self.Deposit_Amount
        print(f"Amount: ${self.Final_Deposit}")

        
    #withdraw: 
    def Withdraw(self):
        self.ask_withdraw = int(input("Withdraw Amount: $"))
        if self.ask_withdraw > self.Final_Deposit: #checks if withdraw is larger than balance
            print("Not Enough Funds.")
            self.balance_savepoint = self.Final_Deposit
            
        else:
            self.Current_balance= self.Final_Deposit - self.ask_withdraw #subtracts withdraw from balance
            self.balance_savepoint = self.Current_balance 
            print(f"Reminaing: ${self.Current_balance}")

        

    #Fees
    def Fee_Calculation(self):#checks if balance is less than 1k, subtracts 10 if so.
        if self.balance_savepoint < 1000:
            self.Fee_calc = self.Current_balance - 10
            self.Current_balance = self.Fee_calc
            print(f"Fee: $10 \nAfter Fee: ${self.Fee_calc}")
        else:
            self.Fee_calc = self.Current_balance



# 3% / 12 (anual) fee, 
#A=P(1+r/n)^nt
#A = Future Value, P = Principal/Present Value, r = rate as decimal, t = time in years, n = number of compounding periods per year | months
# A = self.current Balance * ( 1 + .03/12 )^12*1
    def Interest(self):
        if self.Fee_calc == 0: #checks if the balance wihtin the bank is 0 dollars (user withdraw all money), which means no intrest will build
            self.interest = 0
            print(f"Balance after Interest: ${self.interest} the none one yaur")
        else:
            p = self.balance_savepoint
            r = .03
            n = 12
            t = 1
            Final_amount = p*(1 + r/n)**(n*t)
            self.interest = round(Final_amount, 2 )
            print(f"Balance after Interest: ${self.interest}")


    #string method to convert data type to string instead of memory location popping up in hexa form
    def __str__(self):
        return "Initial Deposit: ${0}\nDeposit: ${1}\nCurrent Balance: ${2}\nWithdraw: ${3}\nAmount After Withdraw: ${4}\nFunds After Fees: ${5}\nInterest Rate of 3% (Annual): ${6}".format(
            self.Initial_Deposit, self.Deposit_Amount, self.Final_Deposit, 
            self.ask_withdraw, self.balance_savepoint, self.Fee_calc, self.interest)
        

