from MyTime import MyTime

t1 = MyTime(200, 259, 30)
t2 = MyTime( 2, 230, 400)
print(t1)
print(t2)


def add_time(t1, t2):
    h = t1.hours + t2.hours
    m = t1.minutes + t2.minutes
    s = t1.seconds + t2.seconds
    sum_t = MyTime(h, m, s)
    return sum_t
    
t3 = add_time(t1,t2)
print(t3)

t4 = t1.add_time(t2) 
print(t4)
    #self        #input

print(t1.after(t2))

#def between(t1, t2, self):
 #   if t1 <= self < t2:
  #      return True
   # else:
    #    return False
   # return t1 <= t2 < t3




#easy testing section
t1 = MyTime(5, 0, 0)
t2 = MyTime(6, 0, 0)
t3 = MyTime(10, 0, 0)


def between_fxn(t1, t2, t3):
    if t1 <= t2 < t3:
        return True
    else:
        return False

print("________________")
#print(obj.between(t1,t2))
#print(between_fxn(t1, obj, t2))
#between(t1, t2,t3)

print(between_fxn(t1,t2 , t3))
print(t2.between(t1,t3))







#between(t1,t2,t3)
#print(t2.between(t1,t2,t3))# is t2 between t1 and t3 as a function
#print(t2.between(t1,t3))# is t2 between t1 and t3 as a method
                        #t2 is self :3
                        #expand after, no longer two times. now three, is player between t1 and t2? what about t2 and t3?
                        #main code need print between codes, then class file with between. ss of how both of them runs.




