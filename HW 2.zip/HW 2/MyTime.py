class MyTime:
    def __init__(self, hrs = 0, mins= 0, secs = 0):
        # self.minutes = mins
        #self.seconds = secs
      # Calculate total seconds to represent
       totalsecs = hrs*3600 + mins*60 + secs
       self.hours = totalsecs // 3600        # Split in h, m, s
       leftoversecs = totalsecs % 3600
       self.minutes = leftoversecs // 60
       self.seconds = leftoversecs % 60
    
    def __str__(self):
        return "{0}:{1}:{2}".format(self.hours, self.minutes, self.seconds)
    
    def add_time(self, t2):
        h = self.hours + t2.hours
        m = self.minutes + t2.minutes
        s = self.seconds + t2.seconds

        while s >= 60:
          s -= 60
          m += 1

        while m >= 60:
            m -= 60
            h += 1

        sum_t = MyTime(h, m, s)
        return sum_t
    
    def increment(self, seconds):
        self.seconds += seconds

        while self.seconds >= 60:
            self.seconds -= 60
            self.minutes += 1

        while self.minutes >= 60:
            self.minutes -= 60
            self.hours += 1
    def to_seconds(self):
            """ Return the number of seconds represented
                by this instance
            """
            return self.hours * 3600 + self.minutes * 60 + self.seconds

    def after(self, time2):
            """ Return True if I am strictly greater than time2 """
            if self.hours > time2.hours:
                 return True
            if self.hours < time2.hours:
                 return False

            if self.minutes > time2.minutes:
                return True
            if self.minutes < time2.minutes:
                return False
            if self.seconds > time2.seconds:
                return True
            return False
    




    def between(self, t1, t2):
         if t1.hours < self.hours < t2.hours: #checks if object hours is between t1/t2
            return True
         
         elif t1.hours == self.hours and t1.minutes <= self.minutes < t2.minutes:# checks if hours are equal and checks mins between t1/t2
              return True
         
         elif t1.hours == self.hours and self.hours == t2.hours and t1.minutes <= self.minutes < t2.minutes:#checks prev and checks mins between t1/2
             return True
         
         elif t1.hours == self.hours and self.hours == t2.hours and t1.minutes == self.minutes and self.minutes == t2.minutes and t1.seconds <= self.seconds < t2.seconds:
              #checks hours/mins then checks seconds if it falls between t1/t2
             return True
         return False
    


    # OVERLOADING section, allows my data type to use booleans in main

    def __le__(self, other): # <= overload
        return self.to_seconds() <= other.to_seconds()

    def __lt__(self, other):
        return self.to_seconds() < other.to_seconds()