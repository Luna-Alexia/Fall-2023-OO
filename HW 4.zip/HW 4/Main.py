from dental import Appointment 
from dental import Month 
from dental import Day 
from dental import Date
#-----------------------#

#appoint = Appointment(11, 20, 2023, "Ortho checkup")

#appoint.checker()

user_choice = input("Please input ""month"", ""day"", ""date"" to check possible appointments: ")
user_choice = user_choice.lower()
if user_choice == "month":
    #checks month
    user_month = int(input("Enter month: "))
    checker = Month(11, 20, 2023, "Ortho checkup", user_month)

if user_choice == "date":
#checks date
    user_date = int(input("Enter Date (year): "))
    checker = Date(11, 20, 2023, "Ortho checkup", user_date)

if user_choice == "day":
    #checks day
    user_day = int(input("Enter Day: "))
    checker = Day(11, 20, 2023, "Ortho checkup", user_day)




#checks date method


#checks day method

#checks month method all has to be if










#Ap = Appointment(11, 20, 2023, "Ortho checkup")
#m = Month()
#m.Occurs_On_Month(Appointment(11, 20, 2023, "Ortho checkup"))
#date = Date()
#date.Occurs_On_Date()

#month = Month(5)

#day = Day()

#date = Date()

