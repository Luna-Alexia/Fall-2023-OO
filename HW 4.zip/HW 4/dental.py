

class Appointment():

    def __init__(self,M = 0 ,D = 0,Y = 0, Desc = ""):
        self.month = M
        self.day = D
        self.year = Y
        self.desc = Desc
      
        self.appointments = [
            (2023, 10, 3, "Dentist appointment"),
            (2023, 20, 8, "Ortho checkup"),
            (2023, 15, 10, "Dental cleaning")
            ]
        
        """
        self.dates_list = []
        self.days_list = []
        self.months_lists = []
        print(self.month)
        """

    #def checker(self):
     #  print(self.month)
      # print(self.day)
        #for i in self.appointments:
         #   for seeker_of_i in i:
          #      return seeker_of_i
    
class Date(Appointment):
    def __init__(self, M, D, Y, Desc = "", date = 0):
        super().__init__(M, D, Y, Desc)
        flag = True

        for i in self.appointments:
            for seeker in i:
                if date == seeker:
                    print(f"Possbile Appointment: {i}")
                    flag = False
                    break
        #if date == Y:
         #   print(f"Appointments that occur on this date: {M}/{D}/{Y} {Desc}")
        if flag == True:
            print("No appointments associated.")

class Day(Appointment):
   def __init__(self, M, D, Y, Desc = "", day = 0):
        super().__init__(M, D, Y, Desc)
        flag = True
        for i in self.appointments:
            for seeker in i:
                if day == seeker:
                    print(f"Possbile Appointment: {i}")
                    flag = False
                    break

        #if day == D:
        #    print(f"Appointments that occur on this Day: {M}/{D}/{Y} {Desc}")
        if flag == True:
            print("No appointments associated.")


class Month(Appointment):
     def __init__(self, M, D, Y, Desc = "", month = 0):
        super().__init__(M, D, Y, Desc)
        flag = True

        for i in self.appointments:
            for seeker in i:
                if month == seeker:
                    print(f"Possbile Appointment: {i}")
                    flag = False
                    break

        #if month == M:
           # print(f"Appointments that occur on this Day: {M}/{D}/{Y} {Desc}")
        if flag == True:
            print("No appointments associated.")











                
"""      

class Month(Appointment):

    def __init__(self, M=0, D=0, Y=0, Desc=""):
        super().__init__(M, D, Y, Desc)
        print(M)
        self.test = M
        print(self.test)


    def Occurs_On_Month(self, classs):
        x = Appointment()
        x.checker()
        
        


        if x.month == x.checker:
            print("True")
        else:
            print("false")
class Day(Appointment):

    def Occurs_On_Day(self):
        return 
    

class Date(Appointment):
    def Occurs_On_Date(self):



       
        x = Day()
        x.Occurs_On_Day()
        y = Appointment()
        y.checker()






    super().__init__(self, M = 0,D = 0,Y = 0, Desc = "")
    #Appointment.__init__(self,M = 0,D = 0,Y = 0, Desc = "")
    print(M)    


    def occursOn(self, M):
        if self.month == M:
            return True
        return False




class Day(Appointment):
    def occursOn(self, D):
        if self.day == D:
            return True
        return False


class Date(Appointment):
   def occursOn(self, Y, D, M):
       if self.year == Y and self.day == D and self.month == M :
           return True
       return False
class Description(Appointment):
    def occursOn(self, Desc):
        if self.desc == Desc:
            return True
        return False
    

"""