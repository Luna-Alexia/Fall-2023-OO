from Itunes import itunesTop
from Itunes import printer
itunes = itunesTop("https://itunes.apple.com/us/rss/topsongs/limit=100/json")

itunes.Name()

#string = printer("hello","hiii","bruhh")
#print(string)

#itunes.check("Teddy Swims")
artist = input("Enter Artist: ")
print("Searching for Name: ")
print(f"Artist Name: {artist}")
itunes.search(artist)