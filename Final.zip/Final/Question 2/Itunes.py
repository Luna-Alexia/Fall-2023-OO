import requests
class itunesTop:

    def __init__(self, url):
        self.url = requests.get(url)
        self.json = self.url.json()
        #self.listName = []
        self.topsongs = []
        #self.album = []

    def Name(self):
        genre = self.json
        for i in range(len(genre["feed"]["entry"])):
            artist = genre["feed"]["entry"][i]["im:artist"]["label"]          
            song = genre["feed"]["entry"][i]["im:name"]["label"]      
            album = genre["feed"]["entry"][i]["im:collection"]["im:name"]["label"]
            self.topsongs.append({"artist": artist, "song": song, "album": album})

        #for song in self.topsongs:
           # print(f"Artist: {song['artist']}, Song: {song['song']}, Album: {song['album']}")
          #  total = printer(artist, song, album)
         #   self.topsongs.append(total)
        #for song in self.topsongs:
           # print(song)
                  
                  
    def search(self, artistName):
        matching = [song for song in self.topsongs if song["artist"] == artistName]
        if matching:
            for i in matching:
                print(f"Artist: {i['artist']}, Song: {i['song']}, Album: {i['album']}")
            else:
                pass

class Album:
    def __init__(self, album) -> None:
        self.album = album
        self.songs = []
    
    def add_song(self, song):
        self.song.apppend(song)
        
    #def check(self, artist):
     #   indexFlag = 0
     #   for i in self.listName:
     #       if i == artist:
     #           print(self.topsongs[indexFlag])
     #           indexFlag += 1


class printer:
    def __init__(self, singer, song, album) -> None:
        self.singer = singer
        self.song = song
        self.album = album
    #def get(self):
     #   return [self.singer, self.song, self.album]
    def __str__(self) -> str:
         return (f"Artist: {self.singer} Song: {self.song} Album: {self.album} \n")

        
