from ShiftSupervisor import ShiftSupervisor
from HireDate import Date

visor = ShiftSupervisor("Luna", "101-A", Date(31, 3, 2023),  1000, 500)

print("----------------------")