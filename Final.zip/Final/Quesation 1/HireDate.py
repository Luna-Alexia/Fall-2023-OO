


class Date():
    def __init__(self, day, month, year):
        self.day = day
        self.month = month
        self.year = year


    

    def format(self):
        return (f"\nHire Day: {self.day} \nMonth: {self.month} \nYear: {self.year}")
