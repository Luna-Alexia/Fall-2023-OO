from Employee import ProductionWorker
from HireDate import Date

class TeamLeader(ProductionWorker):

    def __init__(self, name, number, hireDate, shift, hourly, dayornight, monthlyBonus, annualTrainingReq, trainingHours, trainingHoursNeeded ):
        super().__init__(name, number, hireDate, shift, hourly, dayornight)
        self.monthlybonus = float(monthlyBonus)
        self.annualTrainingReq = annualTrainingReq
        self.traininghours = trainingHours
        self.trainingHoursNeeded = trainingHoursNeeded

        return print(f"Team Leader Name: {self.name} \nEmployee Number: {self.number} \
                     \n-Hire Date- {self.hireDate.format()} \nShift: {self.shift} \
                     \nHourly: {self.hourly} \nTime of Day: {self.DayOrNight} \nMontly Bonus: {self.monthlybonus} \nAnnual Training Hours Req: {self.annualTrainingReq} \
                     \nTraining Hours Completed: {self.traininghours} \nTraining Hours Needed: {self.trainingHoursNeeded}")
