from Employee import Employee
from HireDate import Date
class ShiftSupervisor(Employee):
    def __init__(self, name, hireNumber, hireDate, annualSalary, annualProd):
        super().__init__(name, hireNumber, hireDate)
        self.annualSalary = float(annualSalary)
        self.annualProd = annualProd
        return print(f"Super Visor Name: {self.name} \nEmployee Number: {self.number}\n-Hire Date- {self.hireDate.format()}\nAnnual Salary: {self.annualSalary}\nAnnual Production: {self.annualProd}")
