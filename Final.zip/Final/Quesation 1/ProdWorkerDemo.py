from Employee import ProductionWorker
from HireDate import Date
worker = ProductionWorker("Luna", "101-A", Date(31, 3, 2023), 2, 15, 0)

worker.neededReturn()
print("----------------------")