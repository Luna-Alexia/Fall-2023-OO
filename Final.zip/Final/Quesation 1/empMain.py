from Employee import Employee
from HireDate import Date




emp = Employee("Bob", "101-A", Date(31, 3, 2023))
#---------------------------
#hiredate = Date(23, 4, 2023)
#hiredate.format()

emp.EmployeeInfo()
print("----------------------")