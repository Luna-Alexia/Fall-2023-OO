from HireDate import Date


class Employee():
    def __init__(self, name, hireNumber, hireDate) :
        self.name = name
        self.number = hireNumber
        self.hireDate = hireDate

    def EmployeeInfo(self):
        return print(f"\nEmployee Name: {self.name} \nEmployee Number: {self.number} \nHire Date: {self.hireDate.format()}")

   

class ProductionWorker(Employee):
    def __init__(self, name , number, hireDate, shift, hourly, dayornight):
        super().__init__(name, number, hireDate)
        self.shift = int(shift)
        self.hourly = float(hourly)
    
        if dayornight == 1 or dayornight == 0:
            self.DayOrNight = dayornight
        else:
            self.DayOrNight = "N/A"

    def neededReturn(self):

        return print(f"Name: {self.name}, \nEmployee Number: {self.number}, \n-Hire Date- {self.hireDate.format()} \
                     \nShift: {self.shift}, \nHourly: {self.hourly}, \nTime of Day: {self.DayOrNight}")







