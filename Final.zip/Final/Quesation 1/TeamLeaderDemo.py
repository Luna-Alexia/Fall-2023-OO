from TeamLead import TeamLeader
from HireDate import Date


leader = TeamLeader("Luna", "101-A", Date(31, 3, 2023), 2, 15, 0, 100, 50, 25, 25)
print("----------------------")