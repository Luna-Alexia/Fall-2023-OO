class Student():

    def __init__(self, Id = 0, lastName = "", creditsEarned = 0, courseLoadCredits = 0, Status = 0):

        self.id = Id
        self.LastName = lastName
        self.credits = creditsEarned
        self.currentCourseCreds = courseLoadCredits
        self.stat = Status


    def status(self):
        if self.credits < 30 :
            self.stat = 1
            print(f"Status: Freshman ({self.stat})")

        if self.credits >= 30 and self.credits < 60 :
            self.stat = 2
            print(f"Status: Sophmore ({self.stat})")

        if self.credits >= 60 and self.credits < 90 :
            self.stat = 3
            print(f"Status: Junior ({self.stat})")

        if self.credits >= 90 and self.credits < 120 :
            self.stat = 4
            print(f"Status: Senior ({self.stat})")

        if self.credits >= 120:
            self.stat = 5
            print(f"Status: Grad ({self.stat})")



    def RegesiterCourse(self, addedCred):
        addedCred = abs(addedCred)
        if addedCred > 18:
            print("Error: Cannot exceed 18 credits.")
        else:
            checker = self.currentCourseCreds + addedCred     
            if checker > 18:
                return print("Error: Cannot exceed 18 credits.")
            else:
                self.currentCourseCreds += addedCred   
        print(f"Regesitered Courses: {self.currentCourseCreds}")


    def Withdraw(self, withdraw):
        withdraw = abs(withdraw)
        check =  self.currentCourseCreds - withdraw
        if check < 0:
            return print("Error: Cannot go below 0 credits.") #stops from going negative semester credits
        else:
            self.currentCourseCreds -= withdraw
            print(f"Withdraw: {self.currentCourseCreds}")
        


    def PassedCourse(self, passed):
        if passed > 4:
            print("Cannot exceed 4 credits.")
        else:
            self.currentCourseCreds -= passed
            if self.currentCourseCreds < 0:
                print(f"Error: Cannot go below 0 credits.") #stops the user from going negative current semester credits
            else:
                self.credits += passed
                print(f"Current Credits: {self.currentCourseCreds}")
                print(f"Total Credits: {self.credits}")
            #print(self.currentCourseCreds)

    


    def CreateEmail(self):
        email = ""
        email += self.LastName
        email += str(self.id)
        end = "@rutgers.edu"
        email += end
        print(email)


        