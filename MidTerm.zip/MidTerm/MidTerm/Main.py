from Student import Student
from Grad import Graduate_Student


id = int(input("Enter RUID: "))
lastName = input("Enter Last Name: ")
creditsEarned = int(input("Enter Total Credits Earned: "))
courseLoad = int(input("Enter Current Number of Credits in Progress: "))
status = int(input("Status of Student (1 means freshman, 2 means sophomore, 3 means junior, 4 means senior, 5 means Grad): "))

rutgers = Student(id, lastName, creditsEarned, courseLoad, status)

reg = int(input("Register Credits (Cannot exceed 18): "))
withdraw = int(input("Widthdraw Credits: "))
passed = int(input("Classes Passed: "))
# fresh < 30, 30 < soph < 60, 60 < jnr < 90, 90 < snr < 120

#grad = Graduate_Student()

rutgers.RegesiterCourse(reg)

rutgers.Withdraw(withdraw)

rutgers.PassedCourse(passed)

rutgers.CreateEmail()

rutgers.status()

print("-----Grad_student----")
grad_cred = int(input("Enter Grad Credits: "))
grad_student = Graduate_Student()
grad_student.registerCourse(grad_cred)



#grad_student.registerCourse(5)
#update status
#do status
