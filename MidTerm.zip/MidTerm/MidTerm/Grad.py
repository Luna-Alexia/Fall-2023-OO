from Student import Student

class Graduate_Student(Student):
    def __init__(self, Id=0, lastName="", creditsEarned=0, courseLoadCredits=0, Status=0):
        super().__init__(Id, lastName, creditsEarned, courseLoadCredits, Status)

    def registerCourse(self, grad_credit):
        self.stat = 5
        Main = Student
        if grad_credit > 15:
            print("Error: Cannot exceed 15 credits.")
        else:
            Main.RegesiterCourse(self,grad_credit)


        """
        self.gradc = abs(grad_credit)
        if self.gradc > 15:
            print("Cannot exceed 15 Credits")
        else:
            self.currentCourseCreds =+ self.gradc
            print(f"Registered Grad Classes: {self.currentCourseCreds}")
        


    """