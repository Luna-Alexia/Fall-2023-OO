from MyTime import MyTime

t1 = MyTime(200, 259, 30)
t2 = MyTime( 2, 230, 400)
print(t1)
print(t2)

def add_time(t1, t2):
    h = t1.hours + t2.hours
    m = t1.minutes + t2.minutes
    s = t1.seconds + t2.seconds
    sum_t = MyTime(h, m, s)
    return sum_t
    
t3 = add_time(t1,t2)
print(t3)

t4 = t1.add_time(t2) 
print(t4)
    #self        #input
print(f"{t1.after(t2)}")

print("________________")

#Easy testing for negative time 
t1 = MyTime(-1, 30, 45)
t2 = MyTime(1, 45, 30)
t3 = MyTime(-1, 30, 45)

print("Negative time check:")
print(t1, t2, t3)
print()

#easy testing section
t1 = MyTime(1, 30, 45)
t2 = MyTime(1, 45, 30)
t3 = MyTime(1, 30, 45)


#Uses operators within Overload section
def between_fxn(t1, t2, t3):
    if t1 <= t2 < t3:
        return True
    else:
        return False

print(between_fxn(t1,t2 , t3))
print(t2.between(t1,t3))

print("_______Overload Check___________")
#all false/true is related to the current inputs within testing section
print(t1 == t2) #false
print(t1 == t3) #true
print(t1 > t2)#false
print(t1 < t2)#true
print(t1 <= t2)#true
print( t1 >= t1)#true
print(t1 != t3)#false
print("")

#checks for negative time input, subtracts an hour
print("Subtract Negative Time Check:\n")
t4 = MyTime(0, 0, 0)
t4.increment(-3600)
print(t4)
print("---")
t4.increment(3600)
print(t4)
1