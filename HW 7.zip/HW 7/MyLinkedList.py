from MyNode import Node

class LinkedList:
    def __init__(self):
        self.length = 0
        self.head = None

    def print_backward(self):
        print("[", end=" ")
        if self.head is not None:
            self.head.print_backward()

    def __str__(self):
        # need to complete here
        #print("[", end= " ")
        string = "["
        node = self.head
        while node is not None:
            #print(node, end=" ")
            string += str(node.cargo) 
            if node.next is not None:
                string += ", "
            node = node.next
        string += "]"
        return string
        #print("]")

    def add_first(self, cargo):
        node = Node(cargo)
        node.next = self.head
        self.head = node
        self.length += 1

    def selectionsort(self):
        # adjust the code below to make it work
        node = self.head
        while node is not None: #iterates thru each node in linked list, assumes its the smallest node until it comes across smaller value
            positionOfMin = node
            temp = positionOfMin
            while temp is not None:
                if temp.cargo < positionOfMin.cargo: #when smaller value is found
                    positionOfMin = temp
                temp = temp.next
            temp2 = node.cargo #so value isnt lost, another temp to store current cargo (similar to animation shown in class)
            node.cargo = positionOfMin.cargo
            positionOfMin.cargo = temp2
            node = node.next



        """
        for i in range(0, len(self.items)):
            positionOfMin = i
            for j in range(i + 1, len(self.items)):
                if self.items[j] < self.items[positionOfMin]:
                    positionOfMin = j
            temp = self.items[i]
            self.items[i] = self.items[positionOfMin]
            self.items[positionOfMin] = temp
            """