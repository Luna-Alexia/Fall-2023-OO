from countingMain import Node


def print_list(node):
    #list = []

    print("[", end="")
    flag = True #flags for first object within list
    while node is not None:
        if not flag:
            print(", ", end="")
        print(node, end="")
        #list.append(str(node))
        node = node.next
        flag = False #changes flag to false, marking the first object is passed. stops trailing ,
    print("]")
    
    
    #for i in list:
     #  print(i, end=",")
    #print("]")


node1 = Node(1)
node2 = Node(2)
node3 = Node(3)
node4 = Node(4)
node5 = Node(5)
node1.next = node2
node2.next = node3
node3.next = node4
node4.next = node5
print_list(node1)