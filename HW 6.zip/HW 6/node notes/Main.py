from Node import Node
from Node import Queue
from Card import Card
from Stack import Stack



card1 = Card(1,2)
card2 = Card(3,4)

newq = Queue()
newq.insert(card1)
newq.insert(card2)

stack = Stack()
stack.push(5)
stack.push(6)
stack.push(80)
stack.push(2)
stack.push(10)
stack.push(3)

#print("Top", end=" ")
stack.top()
stack.pop()
stack.peek()
print("min", stack.minElement())
print()

stack.push(card1)
stack.push(card2)

#print(card1)

#print("card min", stack.minElement())