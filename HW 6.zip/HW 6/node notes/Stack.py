class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        return self.items.pop()

    def is_empty(self):
        return (self.items == [])

    def top(self):
        if not self.is_empty():
            last = len(self.items) - 1
            print(self.items[last])
        else:
            print("stack empty")

    def peek(self):
        if not self.is_empty():
            # last = len(self.items)-1
            print(self.items[-1])
        else:
            print("stack empty")

    def minElement(self):
        # complete here
        if not self.is_empty():
            smallest = self.items[0]
            for item in self.items:
                if item < smallest:
                    smallest = item
            return smallest
        else:
            print("Stack is empty.")
